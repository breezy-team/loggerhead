# Release information about loggerhead

version = "1.0-0.13"

description = "Loggerhead is a web viewer for projects in bazaar."

author = "Robey Pointer"
email = "robey@lag.net"

license = "GPL"
url = "http://www.lag.net/loggerhead/"
download_url = "http://www.lag.net/loggerhead/download/..."
